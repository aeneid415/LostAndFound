<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Inventory extends CI_Controller {


	public function __construct()
	{
		parent::__construct();
        $this->load->model('Inventory_Model');  
	}
	
	public function index()
	{
		$this->load->view('login');
	}	

	public function login()
	{		
		$username = $this->input->post('username');
		$password = $this->input->post('password');
		$this->Inventory_Model->login($username, $password);
	}

	public function home(){
		$user_name = $this->session->userdata('username');
		if($user_name == NULL){
			$this->session->set_flashdata('error', 'You are not currently logged in. Please log in to continue.');
			redirect(base_url());
		}else{
			$this->load->view('dashboard');
		}
	}

	public function pgrslips(){
		$user_name = $this->session->userdata('username');
		if($user_name == NULL){
			$this->session->set_flashdata('error', 'You are not currently logged in. Please log in to continue.');
			redirect(base_url());
		}else{
			
			$pgr_data["fetch_pgrdata"] = $this->Inventory_Model->fetch_pgrdata();
			
			$this->load->view('pgrslips', $pgr_data);
			
		}
	}

	public function items(){
		$user_name = $this->session->userdata('username');
		if($user_name == NULL){
			$this->session->set_flashdata('error', 'You are not currently logged in. Please log in to continue.');
			redirect(base_url());
		}else{
			$this->load->view('items');
		}
	}

	public function tracker(){
		$user_name = $this->session->userdata('username');
		if($user_name == NULL){
			$this->session->set_flashdata('error', 'You are not currently logged in. Please log in to continue.');
			redirect(base_url());
		}else{
			$this->load->view('tracker');
		}
	}

	public function accounts(){
		$user_name = $this->session->userdata('username');
		if($user_name == NULL){
			$this->session->set_flashdata('error', 'You are not currently logged in. Please log in to continue.');
			redirect(base_url());
		}else{
			$this->load->view('accounts');
		}
	}

	public function sort(){
		$order = $this->input->post('order');
		 $output = ''; 
		if($order == 'desc')  
		 {  
		      $order = 'asc';  
		 }  
		 else  
		 {  
		      $order = 'desc';  
		 }  
		$column_name = $this->input->post('column_name');
		$query = $this->db->query("SELECT pgf_serial, id_number, CONCAT(last_name, ' ', first_name) AS name, classcode, contact, due_date FROM pgf ORDER BY ".$column_name." ".$order.";");
		
		$output = '<table id="pgr_table" class="table table-borderless table-data3">
                <thead>
                    <tr>
                        <th><a class="column-sort" href="#" id="serial" data-order="'.$order.'">serial</a></th>
                        <th><a class="column-sort" href="#" id="ID number" data-order="'.$order.'">ID number</a></th>
                        <th><a class="column-sort" href="#" id="name" data-order="'.$order.'">name</a></th>
                        <th><a class="column-sort" href="#" id="classcode" data-order="'.$order.'">classcode</a></th>
                        <th><a class="column-sort" href="#" id="contact" data-order="'.$order.'">contact number</a></th>
                        <th><a class="column-sort" href="#" id="due date" data-order="'.$order.'">due date</a></th>
                        <th>'.$order.'</th>
                	</tr>
                </thead>
            <tbody>
		';
		foreach ($query->result() as $row) {
			$output = '<tr>
                            <td>'.$row->pgf_serial.'</td>
                            <td>'.$row->id_number.'</td>
                            <td>'.$row->name.'</td>
                            <td>'.$row->classcode.'</td>
                            <td>'.$row->contact.'</td>
                            <td>'.$row->due_date.'</td>
                            <td>
                                <div class="table-data-feature">
                                    <button class="item" data-toggle="tooltip" data-placement="top" title="Send">
                                        <i class="zmdi zmdi-mail-send"></i>
                                    </button>
                                    <button class="item" data-toggle="tooltip" data-placement="top" title="Edit">
                                        <i class="zmdi zmdi-edit"></i>
                                    </button>
                                    <button class="item" data-toggle="tooltip" data-placement="top" title="Delete">
                                        <i class="zmdi zmdi-delete"></i>
                                    </button>
                                    <button class="item" data-toggle="tooltip" data-placement="top" title="More">
                                        <i class="zmdi zmdi-more"></i>
                                    </button>
                                </div>
                            </td>
                        </tr>';
		}

		$output .= '</tbody>
                </table>';
        echo $output;

	}
}
