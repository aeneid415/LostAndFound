<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Inventory_Model extends CI_Model {

	public function login($username, $password){
		$hashed_pass = md5($password);
		$this->db->where('username', $username);
		$this->db->where('password', $hashed_pass);

		$query = $this->db->get('accounts');
		if ($query->num_rows() > 0){
			foreach ($query->result() as $row){

				
				$sess = array(
					'username' => $row->username,
					'password' => $row->password,
					'first_name' => $row->firstname,
					'last_name' => $row->lastname,
					'type' => $row->type,
					'email' => $row->email,
					'activation' => $row->activation
				);
				
			}
			$this->session->set_userdata($sess);
			if($row->type == 'Admin' && $row->activation == '1'){
				redirect('dashboard');
			}else{
				$this->session->set_flashdata('error', 'This account is inactive!');
				redirect(base_url());
			}
		}else{
			$this->session->set_flashdata('error', 'Invalid username or password!');
			redirect(base_url());
		}

	}

	public function fetch_pgrdata(){
		$query = $this->db->query("SELECT pgf_serial, id_number, CONCAT(last_name, ' ', first_name) AS name, classcode, contact, due_date FROM pgf;");
		
		return $query;
	}
}